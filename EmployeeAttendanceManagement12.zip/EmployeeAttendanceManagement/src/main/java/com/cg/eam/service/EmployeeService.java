package com.cg.eam.service;

import java.util.List;
import java.util.Optional;

import com.cg.eam.entity.Attendance;
import com.cg.eam.entity.Employee;

public interface EmployeeService {

	public Optional<Employee> login(int id);

	public List<Attendance> viewEmployeeAttendance(int id);

	public int viewLop(int id);

	public String applyForLeave(int employeeId, String date);

}
