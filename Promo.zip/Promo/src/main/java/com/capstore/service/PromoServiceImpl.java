package com.capstore.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.capstore.bean.Promo;
import com.capstore.repo.PromoRepo;

@Service
@Transactional
public class PromoServiceImpl implements PromoService {
	@Autowired
	private PromoRepo repo;

	@Override
	public void savePromo(Promo promo) {
		repo.save(promo);
	}

	@Override
	public Promo get(int promo_id) {
		return repo.findById(promo_id).get();
	}

	@Override
	public Iterable<Promo> getAll() {

		return repo.findAll();
	}

}
