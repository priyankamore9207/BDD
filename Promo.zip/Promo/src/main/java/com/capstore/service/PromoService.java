package com.capstore.service;

import com.capstore.bean.Promo;


public interface PromoService {
	
    void savePromo(Promo promo);
	
	Promo get(int promo_id);
	
	Iterable<Promo> getAll();

}
