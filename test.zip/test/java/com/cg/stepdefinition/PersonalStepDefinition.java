package com.cg.stepdefinition;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.PageFactory;

import com.cg.bean.EducationalDetails;
import com.cg.bean.PersonalDetails;

import cucumber.api.java.After;
import cucumber.api.java.Before;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

public class PersonalStepDefinition {
	private WebDriver driver;
	private PersonalDetails personalDetails;
	

	@Before
	public void init() {
		System.setProperty("webdriver.chrome.driver", "lib\\chromedriver1.exe");
		driver = new ChromeDriver();
	}

	@After
	public void destroy() {
			driver.quit();
	}
	
	@Given("^User is on 'Personal Details' Page$")
	public void user_is_on_Personal_Details_Page() throws Throwable {
		driver.get("file:///C:/Users/abadadal/bdd/BDDPractice/htmlfiles/personalDetails.html");
		personalDetails = new PersonalDetails();
		PageFactory.initElements(driver, personalDetails);
	}

	@Then("^Validate Personal Details Page$")
	public void validate_Personal_Details_Page() throws Throwable {
		if(driver.getTitle().equals("Personal Details")) {
			System.out.println("Title of the page is : "+driver.getTitle());
		}
	}

	@When("^user enters invalid firstName$")
	public void user_enters_invalid_firstName() throws Throwable {
		personalDetails.setFirstName("");
		Thread.sleep(1000);
	}

	@Then("^display 'Please fill the First Name'$")
	public void display_Please_fill_the_First_Name() throws Throwable {
		personalDetails.clickNextButton();
		Thread.sleep(1000);
		driver.switchTo().alert().accept();
		Thread.sleep(1000);
	}

	@When("^user enters invalid LastName$")
	public void user_enters_invalid_LastName() throws Throwable {
		personalDetails.setFirstName("Akshata");
		personalDetails.setLastname("");
		Thread.sleep(1000);
	}

	@Then("^display 'Please fill the Last Name'$")
	public void display_Please_fill_the_Last_Name() throws Throwable {
		personalDetails.clickNextButton();
		Thread.sleep(1000);
		driver.switchTo().alert().accept();
		Thread.sleep(1000);
	}
	@When("^user enters invalid email$")
	public void user_enters_invalid_email() throws Throwable {
		personalDetails.setFirstName("Akshata");
		personalDetails.setLastname("Badadale");
		personalDetails.setEmailId("");
		Thread.sleep(1000);
	}

	@Then("^display 'Please fill the Email'$")
	public void display_Please_fill_the_Email() throws Throwable {
		personalDetails.clickNextButton();
		Thread.sleep(5000);
		driver.switchTo().alert().accept();
		Thread.sleep(5000);
	}

	@When("^user enters invalid contact number$")
	public void user_enters_invalid_contact_number() throws Throwable {
		personalDetails.setFirstName("Akshata");
		personalDetails.setLastname("Badadale");
		personalDetails.setEmailId("akshata@gmail.com");
		personalDetails.setContactNo("");
		Thread.sleep(1000);
	}

	@Then("^display 'Please fill valid Contact no\\.'$")
	public void display_Please_fill_valid_Contact_no() throws Throwable {
		personalDetails.clickNextButton();
		Thread.sleep(5000);
		driver.switchTo().alert().accept();
		Thread.sleep(5000);
	}

	@When("^user enters invalid addressLine(\\d+)$")
	public void user_enters_invalid_addressLine(int arg1) throws Throwable {
		personalDetails.setFirstName("Akshata");
		personalDetails.setLastname("Badadale");
		personalDetails.setEmailId("akshata@gmail.com");
		personalDetails.setContactNo("7777024330");
		personalDetails.setAddressLine1("");
		Thread.sleep(1000);
	}

	@Then("^display 'Please fill addressLine(\\d+)'$")
	public void display_Please_fill_addressLine(int arg1) throws Throwable {
		personalDetails.clickNextButton();
		Thread.sleep(5000);
		driver.switchTo().alert().accept();
		Thread.sleep(5000);
	}

	@When("^user enters invalid City$")
	public void user_enters_invalid_City() throws Throwable {
		personalDetails.setFirstName("Akshata");
		personalDetails.setLastname("Badadale");
		personalDetails.setEmailId("akshata@gmail.com");
		personalDetails.setContactNo("7777024330");
		personalDetails.setAddressLine1(" Matoshree 305");
		personalDetails.setAddressLine2("");
		personalDetails.selectCity(0);
		Thread.sleep(1000);
	}

	@Then("^display 'Please fill City'$")
	public void display_Please_fill_City() throws Throwable {
		personalDetails.clickNextButton();
		Thread.sleep(5000);
		driver.switchTo().alert().accept();
		Thread.sleep(5000);
	}

	@When("^user enters invalid State$")
	public void user_enters_invalid_State() throws Throwable {
		personalDetails.setFirstName("Akshata");
		personalDetails.setLastname("Badadale");
		personalDetails.setEmailId("akshata@gmail.com");
		personalDetails.setContactNo("7777024330");
		personalDetails.setAddressLine1(" Matoshree 305");
		personalDetails.setAddressLine2("Airoli navi Mumbai");
		personalDetails.selectCity(1);
		personalDetails.selectState(0);
		Thread.sleep(1000);
	
	}

	@Then("^display 'Please fill the State'$")
	public void display_Please_fill_the_State() throws Throwable {
		personalDetails.clickNextButton();
		Thread.sleep(5000);
		driver.switchTo().alert().accept();
		Thread.sleep(5000);
	}

	@When("^user enters valid details$")
	public void user_enters_valid_details() throws Throwable {
		personalDetails.setFirstName("Akshata");
		personalDetails.setLastname("Badadale");
		personalDetails.setEmailId("akshata@gmail.com");
		personalDetails.setContactNo("7777024330");
		personalDetails.setAddressLine1(" Matoshree 305");
		personalDetails.setAddressLine2("Airoli navi Mumbai");
		personalDetails.selectCity(1);
		personalDetails.selectState(1);
		Thread.sleep(1000);
	}

	@Then("^display 'Personal details are validated'$")
	public void display_Personal_details_are_validated() throws Throwable {
		personalDetails.clickNextButton();
		Thread.sleep(5000);
		driver.switchTo().alert().accept();
		Thread.sleep(5000);
	}

	@Then("^Educational Detail Page should be loaded$")
	public void educational_Detail_Page_should_be_loaded() throws Throwable {
		personalDetails.clickNextButton();
		Thread.sleep(5000);
		driver.switchTo().alert().accept();
		Thread.sleep(5000);
	}
}
