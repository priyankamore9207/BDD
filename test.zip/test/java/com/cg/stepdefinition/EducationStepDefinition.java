package com.cg.stepdefinition;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.PageFactory;

import com.cg.bean.EducationalDetails;
import com.cg.bean.PersonalDetails;

import cucumber.api.java.After;
import cucumber.api.java.Before;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

public class EducationStepDefinition {
	private WebDriver driver;
	private EducationalDetails educationalDetails;
	
	
	
	@Before
	public void init() {
		System.setProperty("webdriver.chrome.driver", "lib\\chromedriver1.exe");
		driver = new ChromeDriver();
	}

	@After
	public void destroy() {
			driver.quit();
	}
	
//	@Given("^User is on Educational Details Page$")
//	public void user_is_on_Educational_Details_Page() throws Throwable {
//		driver = new ChromeDriver();
//		driver.get("file:///C:/Users/abadadal/bdd/BDDPractice/htmlfiles/educationalDetails.html");
//		educationalDetails = new EducationalDetails();
//		PageFactory.initElements(driver, educationalDetails);
//	}

	@Given("^User is on 'Educational Details' Page$")
	public void user_is_on_Educational_Details_Page() throws Throwable {
		driver.get("file:///C:/Users/abadadal/bdd/BDDPractice/htmlfiles/educationalDetails.html");
		educationalDetails = new EducationalDetails();
		PageFactory.initElements(driver, educationalDetails);
	}
	
	@Then("^Validate Educational Details Page$")
	public void validate_Educational_Details_Page() throws Throwable {
		if(driver.getTitle().equals("Educational Details")) {
			System.out.println("Title of the page is : "+driver.getTitle());
		}
	}
	@When("^user enters invalid graduation$")
	public void user_enters_invalid_graduation() throws Throwable {
		educationalDetails.selectGraduation(0);
		Thread.sleep(500);
		
	}

	@Then("^display 'Please Select graduation'$")
	public void display_Please_Select_graduation() throws Throwable {
		educationalDetails.clickNextButton();
		Thread.sleep(1000);
		driver.switchTo().alert().accept();
		Thread.sleep(1000);
	}

	@When("^user enters invalid percentage$")
	public void user_enters_invalid_percentage() throws Throwable {
		educationalDetails.selectGraduation(1);
		educationalDetails.setPercentageDetail("");
		Thread.sleep(5000);
	}

	@Then("^display 'Please Enter percentage'$")
	public void display_Please_Enter_percentage() throws Throwable {
		educationalDetails.clickNextButton();
		Thread.sleep(5000);
		driver.switchTo().alert().accept();
		Thread.sleep(5000);
	}

	@When("^user enters invalid passingYear$")
	public void user_enters_invalid_passingYear() throws Throwable {
		educationalDetails.selectGraduation(1);
		educationalDetails.setPercentageDetail("78%");
		educationalDetails.setPassingYear("");
		Thread.sleep(1000);
	}

	@Then("^display 'Please Enter passingYear'$")
	public void display_Please_Enter_passingYear() throws Throwable {
		educationalDetails.clickNextButton();
		Thread.sleep(1000);
		driver.switchTo().alert().accept();
		Thread.sleep(1000);
	}

	@When("^user enters invalid projectName$")
	public void user_enters_invalid_projectName() throws Throwable {
		educationalDetails.selectGraduation(1);
		educationalDetails.setPercentageDetail("78%");
		educationalDetails.setPassingYear("2015");
		educationalDetails.setProjectName("");
		Thread.sleep(1000);
	}

	@Then("^display 'Please Enter projectName'$")
	public void display_Please_Enter_projectName() throws Throwable {
		educationalDetails.clickNextButton();
		Thread.sleep(1000);
		driver.switchTo().alert().accept();
		Thread.sleep(1000);
	}

	@When("^user enters invalid technologies Used$")
	public void user_enters_invalid_technologies_Used() throws Throwable {
		educationalDetails.selectGraduation(1);
		educationalDetails.setPercentageDetail("78%");
		educationalDetails.setPassingYear("2015");
		educationalDetails.setProjectName("Remote Control");
		educationalDetails.setTechnologiesUsed("");
		Thread.sleep(1000);
	}

	@Then("^display 'Please Enter technologiesUsed'$")
	public void display_Please_Enter_technologiesUsed() throws Throwable {
		educationalDetails.clickNextButton();
		Thread.sleep(1000);
		driver.switchTo().alert().accept();
		Thread.sleep(1000);
	}

	@When("^user enters invalid otherTechnologiesUsed$")
	public void user_enters_invalid_otherTechnologiesUsed() throws Throwable {
		educationalDetails.selectGraduation(1);
		educationalDetails.setPercentageDetail("78%");
		educationalDetails.setPassingYear("2015");
		educationalDetails.setProjectName("Remote Control");
		educationalDetails.setTechnologiesUsed("java");
		Thread.sleep(1000);
	}

	@Then("^display 'Please Enter otherTechnologiesUsed'$")
	public void display_Please_Enter_otherTechnologiesUsed() throws Throwable {
	    educationalDetails.clickNextButton();
		Thread.sleep(1000);
		driver.switchTo().alert().accept();
		Thread.sleep(1000);
	}


	@When("^user enters valid  Educational Details$")
	public void user_enters_valid_Educational_Details() throws Throwable {
		educationalDetails.selectGraduation(1);
		educationalDetails.setPercentageDetail("78%");
		educationalDetails.setPassingYear("2015");
		educationalDetails.setProjectName("Remote Control");
		educationalDetails.setTechnologiesUsed("java");
		educationalDetails.setOthers("dotnet");
		Thread.sleep(1000);
	}

	@Then("^displays 'Educational details successfully filled!!!'$")
	public void displays_Conference_Room_Booking_successfully_done() throws Throwable {
		educationalDetails.clickNextButton();
		Thread.sleep(1000);
		driver.switchTo().alert().accept();
		Thread.sleep(1000);
	}

//	@When("^user clicks Make payment$")
//	public void user_clicks_Make_payment() throws Throwable {
//	    // Write code here that turns the phrase above into concrete actions
//	}
//
//	@Then("^displays 'Your registration has been successfully done!!!'$")
//	public void displays_Your_registration_has_been_successfully_done() throws Throwable {
//	    // Write code here that turns the phrase above into concrete actions
//	}
}
