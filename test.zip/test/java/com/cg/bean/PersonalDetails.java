package com.cg.bean;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.ui.Select;

public class PersonalDetails {
	  
	
	
	@FindBy(id = "txtfirstName")
	WebElement firstName;
	@FindBy(id = "txtlastname")
	WebElement lastname;
	@FindBy(id = "txtemailId")
	WebElement emailId;
	@FindBy(id = "txtcontactNo")
	WebElement contactNo;
	@FindBy(id = "txtaddressLine1")
	WebElement addressLine1;
	@FindBy(id = "txtaddressLine2")
	WebElement addressLine2;
	@FindBy(id = "txtcity")
	WebElement city;
	@FindBy(id = "txtstate")
	WebElement state;
	@FindBy(id="button")
	WebElement nextButton;
	
	public String getFirstName() {
		return firstName.getAttribute("value");
	}
	public void setFirstName(String firstName) {
		this.firstName.sendKeys(firstName);
	}
	public String  getLastname() {
		return lastname.getAttribute("value");
	}
	public void setLastname(String lastname) {
		this.lastname.sendKeys(lastname); 
	}
	public String  getEmailId() {
		return emailId.getAttribute("value");
	}
	public void setEmailId(String emailId) {
		this.emailId.sendKeys(emailId);
	}
	public String  getContactNo() {
		return contactNo.getAttribute("value");
	}
	public void setContactNo(String contactNo) {
		this.contactNo.sendKeys(contactNo);;
	}
	public String getAddressLine1() {
		return addressLine1.getAttribute("value");
	}
	public void setAddressLine1(String addressLine1) {
		this.addressLine1.sendKeys(addressLine1);
	}
	public String getAddressLine2() {
		return addressLine2.getAttribute("value");
	}
	public void setAddressLine2(String addressLine2) {
		this.addressLine2.sendKeys(addressLine2);
	}

	

	public void  selectState(int idx) {
		Select select = new Select(state);
		select.selectByIndex(idx);
	}
	
	public void selectCity(int idx) {
		Select select = new Select(city);
		select.selectByIndex(idx);
	}
	
	public void clickNextButton() {
		nextButton.click();
	}
	
}
