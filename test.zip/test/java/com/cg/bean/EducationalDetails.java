package com.cg.bean;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.ui.Select;

public class EducationalDetails {

	@FindBy(id = "txtgraduation")
	WebElement graduation;
	@FindBy(id = "txtpercentageDetail")
	WebElement percentageDetail;
	@FindBy(id = "txtpassingYear")
	WebElement passingYear;
	@FindBy(id = "txtprojectName")
	WebElement projectName;
	@FindBy(id = "txttechnologiesUsed")
	WebElement technologiesUsed;
	@FindBy(id = "tech")
	WebElement others;
	
	@FindBy(id="button")
	WebElement nextButton;
	

	public void selectGraduation(int idx) {
		Select select = new Select(graduation);
		select.selectByIndex(idx);
	}
	
	public String getPercentageDetail() {
		return percentageDetail.getAttribute("value");
	}
	public void setPercentageDetail(String percentageDetail) {
		this.percentageDetail.sendKeys(percentageDetail);;
	}
	public String getPassingYear() {
		return passingYear.getAttribute("value");
	}
	public void setPassingYear(String passingYear) {
		this.passingYear.sendKeys(passingYear);
	}
	public String getProjectName() {
		return projectName.getAttribute("value");
	}
	public void setProjectName(String projectName) {
		this.projectName.sendKeys(projectName);;
	}
	public String getTechnologiesUsed() {
		return technologiesUsed.getAttribute("value");
	}
	public void setTechnologiesUsed(String technologiesUsed) {
		this.technologiesUsed.sendKeys(technologiesUsed);
	}
	public String getOthers() {
		return others.getAttribute("value");
	}
	public void setOthers(String others) {
		this.others.sendKeys(others);
	}

	public void clickNextButton() {
		nextButton.click();
	}
	
}
