//  Author: Priyanka More

import { Component, OnInit } from '@angular/core';
import { FormControl, Validators, EmailValidator } from '@angular/forms';
import { Router } from '@angular/router';
@Component({
  selector: 'app-forgotpassword',
  templateUrl: './forgotpassword.component.html',
  styleUrls: ['./forgotpassword.component.css']
})
export class ForgotpasswordComponent implements OnInit {
  email = new FormControl('', [Validators.required, Validators.email]);
  // Email validation logic.

  getErrorMessage() {
    return this.email.hasError('required') ? 'You must enter a email' :
      this.email.hasError('email') ? 'Not a valid email' :
        '';
  }
  constructor(private router: Router) {
  }
  ngOnInit() {
  }
  validate() {
    // Navigation path
    this.router.navigate(['/changepassword']);
  }
}
