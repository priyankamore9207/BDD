import { NgModule } from '@angular/core';
import { MatButtonModule, MatFormFieldModule, MatToolbarModule } from '@angular/material';
import { MatCardModule, MatDialogModule, MatInputModule, MatTableModule } from '@angular/material';
import { CommonModule } from '@angular/common';
// Use of Angular Material

@NgModule({
  imports: [
    MatButtonModule,
    MatCardModule,
    MatDialogModule,
    MatInputModule,
    MatFormFieldModule,
    CommonModule,
    MatTableModule,
    MatToolbarModule
  ],
  exports: [
    MatButtonModule,
    MatCardModule,
    MatFormFieldModule,
    CommonModule,
    MatDialogModule,
    MatInputModule,
    MatTableModule,
    MatToolbarModule
  ]
})
export class MaterialModule { }
