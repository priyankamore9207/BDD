import { Component, OnInit, ChangeDetectorRef, NgZone } from '@angular/core';
import { Employee } from '../model/employeeDetails';
import { LoginServiceService } from '../login-service.service';
import { Router, ActivatedRoute } from '@angular/router';
import { filter } from 'rxjs/operators';

@Component({
  selector: 'app-leave',
  templateUrl: './leave.component.html',
  styleUrls: ['./leave.component.css']
})
export class LeaveComponent implements OnInit {
  employeeArr:Employee[] = [];
  employee:any;
  empId: number;
  showAtd = false;
 
  constructor(private router: Router, private service: LoginServiceService, private ref: ChangeDetectorRef,private zone: NgZone, private route: ActivatedRoute ) {
    this.getEmployeeById();

   }

  ngOnInit() {
    this.empId = JSON.parse(localStorage.getItem("CEMPID"));
    this.employee=new Employee;
  }
 

  getEmployeeById() {
    console.log("empID :" + this.empId);
    this.service.getEmployeeById(this.empId).subscribe(res => {
      if (res == null) {
        res = new Employee;
      }
      this.setEmployee(this.employee);
      console.log(res);
    }
    );
    this.showAtd = true;
  }

  setEmployee(emp: Employee) {
    console.log(emp);
    this.employee = emp;
   
  }

  }


