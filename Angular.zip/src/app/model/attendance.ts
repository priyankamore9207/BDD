import { Employee } from './employeeDetails';

export class Attendance {

    id: number;
    present: String;
    emp: Employee;
    date : String;
}