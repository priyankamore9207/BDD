package com.cg.step;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.PageFactory;

import com.cg.bean.Login;

import cucumber.api.java.After;
import cucumber.api.java.Before;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

public class LoginStepDefinition2 {
	private WebDriver driver;
	Login login;

	@Before
	public void init() {
		// instantiate driver
		System.setProperty("webdriver.chrome.driver", "mydriver\\chromedriver.exe");
		driver = new ChromeDriver();
	}

	@After
	public void destroy() {
		driver.quit();
	}
  
	@When("^user enters user$")
	public void user_enters_user() throws Throwable {
		// Write code here that turns the phrase above into concrete actions
		login.selectUser(0);

	}

	@Then("^Validate user$")
	public void validate_user() throws Throwable {
		// Write code here that turns the phrase above into concrete actions
		login.clickLogin();
		Thread.sleep(2000);
		driver.switchTo().alert().accept();
		Thread.sleep(2000);
	}

	@Given("^User is on login page$")
	public void user_is_on_login_page() throws Throwable {

		login = new Login();
		PageFactory.initElements(driver, login);
		String url = "file:///C:/Users/priyamor/HelloBDD/html/login.html";
		driver.get(url);
	}

	@When("^user enters username$")
	public void user_enters_username() throws Throwable {
		login.selectUser(0);
		login.setUsername("abc");
	}

	@Then("^Validate username$")
	public void validate_username() throws Throwable {
		login.clickLogin();
		Thread.sleep(2000);
		driver.switchTo().alert().accept();
		Thread.sleep(2000);
	}

	@When("^User enters password$")
	public void user_enters_password() throws Throwable {
		//login.selectUser(0);
		login.selectUser(0);
		login.setUsername("abcd");
		login.setPassword("123");
	}

	@Then("^Validate password$")
	public void validate_password() throws Throwable {
		login.clickLogin();
		Thread.sleep(2000);
		driver.switchTo().alert().accept();
		Thread.sleep(2000);
	}

	@When("^User enters role$")
	public void user_enters_role() throws Throwable {
		// Write code here that turns the phrase above into concrete actions
		login.selectUser(0);
		login.setUsername("abcd");
		login.setPassword("1234");
		login.selectRole(1);

	}

	@Then("^Validate role$")
	public void validate_role() throws Throwable {
		// Write code here that turns the phrase above into concrete actions
		login.clickLogin();
		Thread.sleep(2000);
		driver.switchTo().alert().accept();
		Thread.sleep(2000);
	}

	@When("^user submit form$")
	public void user_submit_form() throws Throwable {
		login.selectUser(0);
		login.setUsername("abcd");
		login.setPassword("1234");
		login.selectRole(1);
	}

	@Then("^show successful alert$")
	public void show_successful_alert() throws Throwable {
		// WebElement form = driver.findElement(By.tagName("form"));
		// form.submit();
		login.clickLogin();
		Thread.sleep(2000);
		driver.switchTo().alert().accept();
		Thread.sleep(2000);
	}
}
