package com.cg.step;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

import com.cg.bean.Education;

import cucumber.api.java.After;
import cucumber.api.java.Before;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

public class EducationStepDefinition {
	private WebDriver driver;
	Education education;

	@Before
	public void init() {
		// instantiate driver
		System.setProperty("webdriver.chrome.driver", "mydriver\\chromedriver.exe");
		driver = new ChromeDriver();
	}

	@After
	public void destroy() {
		driver.quit();
	}

	@Given("^User is on Eductaion Detail Page$")
	public void user_is_on_Eductaion_Detail_Page() throws Throwable {

	}

	@When("^user enetrs invalid graduation$")
	public void user_enetrs_invalid_graduation() throws Throwable {

	}

	@Then("^display Please fill the graduation$")
	public void display_Please_fill_the_graduation() throws Throwable {

	}

	@When("^user enetrs invalid percentage$")
	public void user_enetrs_invalid_percentage() throws Throwable {

	}

	@Then("^display Please fill the percentage$")
	public void display_Please_fill_the_percentage() throws Throwable {

	}

	@When("^user enetrs invalid passingYear$")
	public void user_enetrs_invalid_passingYear() throws Throwable {

	}

	@Then("^display Please fill the passingYear$")
	public void display_Please_fill_the_passingYear() throws Throwable {

	}

	@When("^user enetrs invalid projectName$")
	public void user_enetrs_invalid_projectName() throws Throwable {

	}

	@Then("^display Please fill the projectName$")
	public void display_Please_fill_the_projectName() throws Throwable {

	}

	@When("^user enetrs invalid technologyUsed$")
	public void user_enetrs_invalid_technologyUsed() throws Throwable {

	}

	@Then("^display Please fill the technologyUsed$")
	public void display_Please_fill_the_technologyUsed() throws Throwable {

	}

	@When("^user enetrs invalid otherTechnology$")
	public void user_enetrs_invalid_otherTechnology() throws Throwable {

	}

	@Then("^display Please fill the otherTechnology$")
	public void display_Please_fill_the_otherTechnology() throws Throwable {

	}

}
