package com.cg.step;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

import com.cg.bean.Personal;

import cucumber.api.java.After;
import cucumber.api.java.Before;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

public class PersonalStepDefinition {
	private WebDriver driver;
	Personal personal;

	@Before
	public void init() {
		// instantiate driver
		System.setProperty("webdriver.chrome.driver", "mydriver\\chromedriver.exe");
		driver = new ChromeDriver();
	}

	@After
	public void destroy() {
		driver.quit();
	}

	@Given("^User is on Personal Detail Page$")
	public void user_is_on_Personal_Detail_Page() throws Throwable {

	}

	@When("^user enetrs invalid firstName$")
	public void user_enetrs_invalid_firstName() throws Throwable {

	}

	@Then("^display Please fill the First Name$")
	public void display_Please_fill_the_First_Name() throws Throwable {

	}

	@When("^user enetrs invalid lastName$")
	public void user_enetrs_invalid_lastName() throws Throwable {

	}

	@Then("^display Please fill the Last Name$")
	public void display_Please_fill_the_Last_Name() throws Throwable {

	}

	@When("^user enetrs invalid email$")
	public void user_enetrs_invalid_email() throws Throwable {

	}

	@Then("^display Please fill the Email$")
	public void display_Please_fill_the_Email() throws Throwable {

	}

	@When("^user enetrs invalid contact number$")
	public void user_enetrs_invalid_contact_number() throws Throwable {

	}

	@Then("^display Please fill valid Contact no\\.$")
	public void display_Please_fill_valid_Contact_no() throws Throwable {

	}

	@When("^user enetrs invalid AddressLine(\\d+)$")
	public void user_enetrs_invalid_AddressLine(int arg1) throws Throwable {

	}

	@Then("^display Please fill AddressLine(\\d+)$")
	public void display_Please_fill_AddressLine(int arg1) throws Throwable {

	}

	@When("^user enetrs invalid City$")
	public void user_enetrs_invalid_City() throws Throwable {

	}

	@Then("^display Please fill City$")
	public void display_Please_fill_City() throws Throwable {

	}

	@When("^user enetrs invalid State$")
	public void user_enetrs_invalid_State() throws Throwable {

	}

	@Then("^display Please fill the State$")
	public void display_Please_fill_the_State() throws Throwable {

	}

}
