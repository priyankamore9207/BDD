package com.cg.bean;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.ui.Select;

public class Education {
	@FindBy(id = "graduation")
	private WebElement graduation;

	@FindBy(id = "percentage")
	private WebElement percentage;

	@FindBy(id = "passingYear")
	private WebElement passingYear;

	@FindBy(id = "projectName")
	private WebElement projectName;

	@FindBy(id = "technologyUsed")
	private WebElement technologyUsed;

	@FindBy(id = "otherTechnology")
	private WebElement otherTechnology;

//	public String getGraduation() {
//		return graduation.getAttribute("value");
//	}
//
//	public void setGraduation(String graduation) {
//		this.graduation.sendKeys(graduation);
//		
//	}
	public void selectGraduation(int idx) {
		Select select = new Select(graduation);
		select.selectByIndex(idx);
	}

	public String getPercentage() {
		return percentage.getAttribute("value");
	}

	public void setPercentage(String percentage) {
		this.percentage.sendKeys(percentage);

	}

	public String getPassingYear() {
		return passingYear.getAttribute("value");
	}

	public void setPassingYear(String passingYear) {
		this.passingYear.sendKeys(passingYear);

	}

	public String getProjectName() {
		return projectName.getAttribute("value");
	}

	public void setProjectName(String projectName) {
		this.projectName.sendKeys(projectName);

	}

	public String getTechnologyUsed() {
		return technologyUsed.getAttribute("value");
	}

	public void setTechnologyUsed(String technologyUsed) {
		this.technologyUsed.sendKeys(technologyUsed);

	}

	public String getOtherTechnology() {
		return otherTechnology.getAttribute("value");
	}

	public void setOtherTechnology(String otherTechnology) {
		this.otherTechnology.sendKeys(otherTechnology);

	}

}
